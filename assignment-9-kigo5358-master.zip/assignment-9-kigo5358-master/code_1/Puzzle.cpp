#include "Puzzle.hpp"
#include <vector>
#include <stack>
#include <iostream>

using namespace std;

Puzzle::Puzzle(int n){
    this->n = n;
}

void Puzzle::addEdge(int v1, int v2){
    //TODO
}

void Puzzle::addVertex(int num){
    //TODO
}

void Puzzle::displayEdges(){
    //TODO
}

// Finds the vertex number from the position of the open path in the maze
int Puzzle::findVertexNumFromPosition(int x, int y){
    //TODO
    return 0;
}

// Creates a default maze of all 1s of size n x n, except for positions (0,0) and (n-1, n-1)
void Puzzle::createDefaultPuzzle(){
    //TODO
}

void Puzzle::createPath(int i, int j){
    //TODO
}

void Puzzle::printPuzzle(){
    //TODO
}

vector<int> Puzzle::findOpenAdjacentPaths(int x, int y){
    vector<int> neighbors; 
    for(int i = x-1; i <= x + 1; i++){
        if(i < 0 || i >= n){
            continue;
        }
        for(int j = y-1; j <= y+1; j++){
            if(j < 0 || j >= n){
                continue;
            }
            // if there is an open path at this adjacent position, add to adjArray
            if(!(i == x && j == y) && puzzle[i][j] == 0){
                neighbors.push_back(findVertexNumFromPosition(i, j));
            }
        }
    }
    return neighbors;
}

void Puzzle::convertPuzzleToAdjacencyListGraph(){
    //TODO
}

bool Puzzle::findPathThroughPuzzle(){
    //TODO
    return false;
}

bool Puzzle::checkIfValidPath(){
    //TODO
    return false;
}

Puzzle::~Puzzle(){
    if (n > 0){
        for(int i = 0; i < n; i++){
            delete[] puzzle[i];
        }
        delete[] puzzle;
    }
    for (unsigned int i = 0; i< vertices.size(); i++){
        delete vertices[i]; 
    }
}
